# Terraform 

- GKE Cluster creation
- Apigee entities like environment and environment groups (TBD)