files for cassandra backup manifests
